from setuptools import setup, find_packages

setup(
    name='example_package',
    version='0.1.0',
    packages=['example_package'],
    install_requires=[],
)